module MTG.Deck.Builder.gui {
    
    
    
    
       
    requires javafx.graphics;
    requires javafx.fxml;
    requires java.desktop;
    requires javafx.controls;
    requires MTG.Deck.Builder.shared;
    requires MTG.Deck.Builder.api;
    requires MTG.Deck.Builder.data;

    exports gui;
    
}