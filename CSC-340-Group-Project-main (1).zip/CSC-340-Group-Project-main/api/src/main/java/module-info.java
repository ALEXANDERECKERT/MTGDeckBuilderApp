module MTG.Deck.Builder.api {
    requires org.json;
    requires MTG.Deck.Builder.shared;
    //requires animal.sniffer.annotations;
    exports api;


}