module MTG.Deck.Builder.shared {
    requires MTG.Deck.Builder.data;
    opens shared;
    exports shared;
}