module MTG.Deck.Builder.data {
    exports errors;
    exports manager;
    exports annotations;
    requires java.sql;
}