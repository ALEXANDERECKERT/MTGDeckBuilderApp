module MTG.Deck.Builder.app {
    requires MTG.Deck.Builder.api;
    requires MTG.Deck.Builder.data;
    requires MTG.Deck.Builder.gui;
    requires javafx.graphics;
    requires java.desktop;
}